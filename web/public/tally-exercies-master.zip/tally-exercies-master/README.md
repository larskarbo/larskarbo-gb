# LiquidList - Finding Compound accounts in danger of liquidation

```bash
cd web
yarn
yarn start # runs nextjs server on http://localhost:3000
```