module.exports = {
  images: {
    domains: [],
  },
  poweredByHeader: false,
};
