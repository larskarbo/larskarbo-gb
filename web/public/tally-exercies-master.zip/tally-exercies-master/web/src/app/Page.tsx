import useSWR from "swr";
import EthAddress from "./components/EthAddress";
import { compoundFetcher } from "./compoundFetcher";
import { priceToReadable } from "./utils/priceToReadable";

export const Page = ({ idx }) => {
  const { data } = useSWR(["https://api.compound.finance/api/v2/account", idx], compoundFetcher);

  if (!data) {
    return null;
  }

  return (
    <div className="">
      <div className="flex flex-col gap-4">
        <div className="flex gap-8 text-gray-300 text-xs">
          <h1 className="w-36">Address</h1>
          <div className="w-72">Collateral value</div>
          <div className="w-72">Borrowed value</div>
        </div>
        {data.accounts.map((account) => (
          <div className="flex gap-8" key={account.address}>
            <h1 className="w-36">
              <EthAddress address={account.address} />
            </h1>
            <div className="w-72 text-xs">{priceToReadable(account.total_collateral_value_in_eth.value)}</div>
            <div className="w-72 text-xs">{priceToReadable(account.total_borrow_value_in_eth.value)}</div>
          </div>
        ))}
      </div>
    </div>
  );
};
