export interface Health {
  value: string;
}

export interface BorrowBalanceUnderlying {
  value: string;
}

export interface LifetimeBorrowInterestAccrued {
  value: string;
}

export interface LifetimeSupplyInterestAccrued {
  value: string;
}

export interface SafeWithdrawAmountUnderlying {
  value: string;
}

export interface SupplyBalanceUnderlying {
  value: string;
}

export interface Token {
  address: string;
  borrow_balance_underlying: BorrowBalanceUnderlying;
  lifetime_borrow_interest_accrued: LifetimeBorrowInterestAccrued;
  lifetime_supply_interest_accrued: LifetimeSupplyInterestAccrued;
  safe_withdraw_amount_underlying: SafeWithdrawAmountUnderlying;
  supply_balance_underlying: SupplyBalanceUnderlying;
  symbol: string;
}

export interface TotalBorrowValueInEth {
  value: string;
}

export interface TotalCollateralValueInEth {
  value: string;
}

export interface Account {
  address: string;
  block_updated?: any;
  health: Health;
  tokens: Token[];
  total_borrow_value_in_eth: TotalBorrowValueInEth;
  total_collateral_value_in_eth: TotalCollateralValueInEth;
}

export interface PaginationSummary {
  page_number: number;
  page_size: number;
  total_entries: number;
  total_pages: number;
}

export interface MaxHealth {
  value: string;
}

export interface MinBorrowValueInEth {
  value: string;
}

export interface Request {
  addresses: any[];
  block_number: number;
  block_timestamp: number;
  max_health: MaxHealth;
  min_borrow_value_in_eth: MinBorrowValueInEth;
  network: string;
  page_number: number;
  page_size: number;
}

export interface RootObject {
  accounts: Account[];
  error?: any;
  pagination_summary: PaginationSummary;
  request: Request;
}
