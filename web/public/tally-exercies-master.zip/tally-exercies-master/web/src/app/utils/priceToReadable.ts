import { round, toNumber } from "lodash";

export const priceToReadable = (price: string) => {
  if (isZero(price)) {
    return 0;
  }
  return price + `Ξ`;
  return round(toNumber(price), 6) + `Ξ`;
};

function isZero(price: string) {
  return /^0*$/.test(price.replace(".", ""));
}
