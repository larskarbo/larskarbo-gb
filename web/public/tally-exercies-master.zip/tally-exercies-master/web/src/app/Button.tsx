import clsx from "clsx";
import Link from "next/link";
import React from "react";
import { FaSpinner } from "react-icons/fa";

export default function Button({
  onClick = null,
  disabled = false,
  style = "dark-default",
  icon = null,
  children = null,
  className = "",
  loading = false,
  linkTo = null,
}: {
  [key: string]: any;
}) {
  const Comp = linkTo ? "a" : "button";

  let buttonStyles = " bg-gray-900 ";
  let hoverStyles = "";

  if (style == "dark-default") {
    buttonStyles = "bg-gray-900";
    hoverStyles = "";
  } else if (style == "yellow") {
    buttonStyles = "bg-yellow-400 text-yellow-900";
    hoverStyles = "";
  } else if (style == "green") {
    buttonStyles = "bg-green-400 text-green-900";
    hoverStyles = "";
  }

  const isDisabled = disabled || loading;
  const inside = (
    <Comp
      className={clsx(
        className,
        `flex center font-medium ${buttonStyles} whitespace-nowrap rounded-xl py-2 px-4 text-sm`,
        !isDisabled && `${hoverStyles} transition-colors duration-150 hover:shadow-sm`,
        isDisabled && "text-gray-400 cursor-default"
      )}
      onClick={isDisabled ? null : onClick}
      disabled={isDisabled}
    >
      <div className=" flex items-center">
        {icon && !loading && <div className="mr-2">{icon}</div>}
        {loading && (
          <div className="mr-1">
            <FaSpinner className="animate-spin" />
          </div>
        )}
        {children}
      </div>
    </Comp>
  );

  if (linkTo) {
    return <Link href={linkTo}>{inside}</Link>;
  }

  return inside;
}
