import copy from "copy-to-clipboard";
import { useEffect, useState } from "react";
export default function EthAddress({ address }: { address: string }) {
  const [copied, setCopied] = useState(false);
  useEffect(() => {
    if (copied) {
      setTimeout(() => {
        setCopied(false);
      }, 3000);
    }
  }, [copied]);

  return (
    <button
      className="hover:bg-gray-700 w-32 text-sm text-gray-300 py-1 bg-gray-800 transform active:scale-90 scale-100 transition-transform  px-2 rounded"
      onClick={() => {
        copy(address);
        setCopied(true);
      }}
    >
      {copied ? (
        <>Copied!</>
      ) : (
        <>
          {address.substr(0, 6)}...{address.substr(address.length - 4)}
        </>
      )}
    </button>
  );
}
