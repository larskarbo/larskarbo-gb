import axios from "axios";
import { RootObject } from "./types";

const page_size = 15;
export const compoundFetcher = (url: string, idx: number): Promise<RootObject> => {
  return axios
    .post(url, {
      addresses: [],
      // returns all accounts if empty or not included
      block_number: 0,
      // returns latest if given 0
      max_health: {
        value: "1.0",
      },
      page_number: idx,
      page_size: page_size,
    })
    .then((response) => {
      return response.data;
    })
    .catch((err) => {
      console.log("error:", err);
      return err;
    });
};
