import PlausibleProvider from "next-plausible";
import Head from "next/head";
import React from "react";
import "../styles.css";
import "../tailwind.css";

function MyApp({ Component, pageProps }) {
  return (
    <>
      <PlausibleProvider domain="rudeboys.io">
        <Head>
          <meta property="og:site_name" content="Rude Boy's" />
        </Head>
        <div className="flex flex-col items-center mfain  pt-0 text-white  min-h-screen" style={{}}>
          <div className=" w-full ">
            <div className="my-4 px-8 lg:px-0 ">
              <Component {...pageProps} />
            </div>
          </div>
        </div>
      </PlausibleProvider>
    </>
  );
}

export default MyApp;
