import { QuickSeo } from "next-quick-seo";
import React, { useState } from "react";
import useSWR from "swr";
import Button from "../app/Button";
import { compoundFetcher, Page } from "../app/Page";

export default function FrontPage() {
  const [pageIndex, setPageIndex] = useState(1);

  const { data } = useSWR(["https://api.compound.finance/api/v2/account", 1], compoundFetcher);

  return (
    <div className="max-w-4xl mx-auto">
      <QuickSeo title={"LiquidList - Finding Compound accounts in danger of liquidation"} />

      {data && (
        <div className="mb-8">{data.pagination_summary.total_entries} accounts are in danger of liquidation</div>
      )}
      <div className="mb-8">index: {pageIndex}</div>
      <div className="flex gap-8 my-8">
        <Button disabled={!(pageIndex > 1)} onClick={() => setPageIndex(1)}>
          First
        </Button>
        <Button disabled={!(pageIndex > 1)} onClick={() => setPageIndex(pageIndex - 1)}>
          Previous
        </Button>
        <Button
          disabled={data && pageIndex == data.pagination_summary.total_pages}
          onClick={() => setPageIndex(pageIndex + 1)}
        >
          Next
        </Button>
        <Button
          disabled={!data || pageIndex == data.pagination_summary.total_pages}
          onClick={() => data && setPageIndex(data.pagination_summary.total_pages)}
        >
          Last
        </Button>
      </div>
      <Page idx={pageIndex} />
      <div className="hidden">
        <Page idx={pageIndex - 1} />
        <Page idx={pageIndex + 1} />
      </div>
    </div>
  );
}
