module.exports = {
  printWidth: 120,
};
